USE Training_23Jan19_Pune

SELECT Stud_Code
FROM Student_master
UNION
SELECT Stud_Code
FROM Book_Transaction

SELECT Stud_Code
FROM Student_master
UNION ALL
SELECT Stud_Code
FROM Book_Transaction

SELECT Stud_Code
FROM Student_master
INTERSECT
SELECT Stud_Code
FROM Book_Transaction

SELECT Stud_Code
FROM Student_master
EXCEPT
SELECT Stud_Code
FROM Book_Transaction