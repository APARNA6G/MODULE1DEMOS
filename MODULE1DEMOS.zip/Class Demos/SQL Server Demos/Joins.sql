USE Training_23Jan19_Pune

SELECT * FROM Student_master
SELECT * FROM Book_Transaction
SELECT * FROM Book_Master
SELECT * FROM Staff_Master

--CROSS JOIN
SELECT bt.Book_code, sm.Stud_Code, sm.Stud_Name, bt.Issue_date
FROM Book_Transaction bt, Student_master sm

SELECT bt.Book_code, sm.Stud_Code, sm.Stud_Name, bt.Issue_date
FROM Book_Transaction bt CROSS JOIN Student_master sm

--Inner Join
--Display book transaction details with student name
SELECT bt.Book_code, sm.Stud_Code, sm.Stud_Name, bt.Issue_date
FROM Book_Transaction bt, Student_master sm
WHERE bt.Stud_code = sm.Stud_Code

SELECT bt.Book_code, sm.Stud_Code, sm.Stud_Name, bt.Issue_date
FROM Book_Transaction bt INNER JOIN Student_master sm
ON bt.Stud_code = sm.Stud_Code

--Display the student name with book name which is issued by student
SELECT bm.Book_code, bm.Book_name, sm.Stud_Code, sm.Stud_Name
FROM Book_Transaction bt
INNER JOIN Book_Master bm
ON bt.Book_code = bm.Book_code
INNER JOIN Student_master sm
ON bt.Stud_code = sm.Stud_Code

--Outer Join
--Left Outer Join
--Display book transaction details for all students whether they issued the book or not
SELECT sm.Stud_Code, sm.Stud_Name, bt.Book_code
FROM Student_master sm LEFT OUTER JOIN Book_Transaction bt
ON sm.Stud_Code = bt.Stud_code

--Display book transaction details for all books whether it is issued by student or not
SELECT sm.Stud_Code, sm.Stud_Name, bt.Book_code
FROM Student_master sm RIGHT OUTER JOIN Book_Transaction bt
ON sm.Stud_Code = bt.Stud_code

--Display all book and students whether it is issued or not
SELECT sm.Stud_Code, sm.Stud_Name, bt.Book_code
FROM Student_master sm FULL OUTER JOIN Book_Transaction bt
ON sm.Stud_Code = bt.Stud_code

--Self Join
--Display Staff name with manager name

SELECT emp.Staff_Code, emp.Staff_Name, mgr.Staff_Name Manager_Name
FROM Staff_Master emp
INNER JOIN Staff_Master mgr
ON emp.Mgr_code = mgr.Staff_Code


--Display student marks with student name
SELECT s.Stud_Code, s.Stud_Name, m.Subject1, m.Subject2, m.Subject3
FROM Student_master s INNER JOIN Student_Marks m
ON s.Stud_Code = m.Stud_Code

--Display name of books which are issued by staff
SELECT bt.Book_code, bm.Book_Name, bt.Staff_Code
FROM Book_Transaction bt INNER JOIN Book_Master bm
ON bt.Book_code = bm.Book_code
INNER JOIN Staff_Master sm
ON bt.Staff_code = sm.Staff_Code

--Display name of books and staff name which are issued by staff
SELECT bt.Book_code, bm.Book_Name, sm.Staff_Code, sm.Staff_Name
FROM Book_Transaction bt INNER JOIN Book_Master bm
ON bt.Book_code = bm.Book_code
INNER JOIN Staff_Master sm
ON bt.Staff_code = sm.Staff_Code

--Display department name for student
SELECT sm.Stud_Code, sm.Stud_Name, dm.Dept_Code, dm.Dept_Name
FROM Student_master sm INNER JOIN Department_master dm
ON sm.Dept_Code = dm.Dept_code

--Display department name and designation name of staff
SELECT sm.Staff_Code, sm.Staff_Name, dept.Dept_Name, des.Design_Name
FROM Staff_Master sm INNER JOIN Department_master dept
ON sm.Dept_Code = dept.Dept_code
INNER JOIN Desig_master des
ON sm.Des_Code = des.Design_Code

--Display all books whether they are issued by staff or not
SELECT bt.Book_Code, sm.Staff_Code, sm.Staff_Name
FROM Book_Transaction bt LEFT OUTER JOIN Staff_Master sm
ON bt.Staff_code = sm.Staff_Code

--Display book transaction details and all staff details, whether the staff has issued the book or not
SELECT bt.Book_Code, sm.Staff_Code, sm.Staff_Name
FROM Book_Transaction bt RIGHT OUTER JOIN Staff_Master sm
ON bt.Staff_code = sm.Staff_Code