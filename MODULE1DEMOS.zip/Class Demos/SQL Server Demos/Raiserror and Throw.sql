BEGIN TRY
	DECLARE @result INT
	SET @result = 1/0
END TRY
BEGIN CATCH
	DECLARE @errormessage	VARCHAR(200)
	DECLARE @severity		INT
	
	SET @errormessage	= ERROR_MESSAGE()
	SET @severity		= ERROR_SEVERITY()

	RAISERROR(@errormessage, @severity, 1)
END CATCH

GO
--Using Throw
BEGIN TRY
	DECLARE @result INT
	SET @result = 1/0
END TRY
BEGIN CATCH
	THROW
END CATCH

SELECT * FROM sysmessages