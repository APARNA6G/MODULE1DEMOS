USE Training_23Jan19_Pune

SELECT STR(23)

SELECT REPLACE('Pearls are pretty', 'are', 'XXXX')

SELECT REPLACE(Stud_Name, 'e', 'XX')
FROM Student_Master

SELECT LEFT('Pearls are pretty', 3)

SELECT LEFT(Stud_Name, 2)
FROM Student_master

SELECT RIGHT('Pearls are pretty', 3)

SELECT RIGHT(Stud_Name, 2)
FROM Student_master

SELECT SUBSTRING('Pearls are pretty', 4, 6)

SELECT LEN('Pearls are pretty')

SELECT REVERSE('Pearls are pretty')

SELECT LOWER('Pearls are pretty')

SELECT UPPER('Pearls are pretty')

SELECT Stud_Name + ' has student code' + STR(Stud_Code)
FROM Student_master