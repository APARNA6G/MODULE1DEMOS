USE Training_23Jan19_Pune

SELECT COUNT(*)
FROM Student_Master

SELECT COUNT(Address)
FROM Student_Master

SELECT * FROM Student_master WHERE Address IS NOT NULL

SELECT SUM(Subject1) Total, AVG(Subject1) Average
FROM Student_Marks

SELECT MIN(Subject1) Minimum, MAX(Subject1) Maximum
FROM Student_Marks