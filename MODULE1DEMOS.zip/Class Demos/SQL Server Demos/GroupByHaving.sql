USE Training_23Jan19_Pune

SELECT COUNT(Stud_Code) StudentCount
FROM Student_master

--Department wise student count
SELECT Dept_Code, COUNT(Stud_Code) Student_Count
FROM Student_Master
GROUP BY Dept_Code

--Department wise Staff count
SELECT Dept_Code, COUNT(Staff_Code) Staff_Count
FROM Staff_Master
GROUP BY Dept_Code

--Department wise staff count, total salary and average salary
SELECT Dept_Code, COUNT(Staff_Code) Staff_Count, SUM(Salary) Total_Salary, AVG(Salary) Average_Salary
FROM Staff_Master
GROUP BY Dept_Code

--Department and Designation wise Staff count, total and average salary
SELECT Dept_Code, Des_Code, COUNT(Staff_Code) Staff_Count, SUM(Salary) Total_Salary, AVG(Salary) Average_Salary
FROM Staff_Master
GROUP BY Dept_Code, Des_Code

--Find the number of students as per the address
SELECT Address, COUNT(Stud_Code)
FROM Student_master
GROUP BY Address

--Display the number of students as per city, where the city has more than 1 student
SELECT Address, COUNT(Stud_Code)
FROM Student_master
GROUP BY Address
HAVING COUNT(Stud_Code) > 1


select * from Student_master