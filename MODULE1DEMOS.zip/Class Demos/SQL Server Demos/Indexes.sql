USE Training_23Jan19_Pune

EXEC sp_help Emp_115022

EXEC sp_helpindex Emp_115022