USE Training_23Jan19_Pune

GO
CREATE SCHEMA Shital
GO

CREATE TABLE Shital.Prod
(
	ProdID	INT,
	Name	VARCHAR(20),
	Quantity INT
)

SELECT * FROM Shital.Prod

