USE Training_23Jan19_Pune

GO
CREATE DEFAULT Email_Default_115022
AS 'hr@cg.com'

GO

EXEC sp_bindefault Email_Default_115022, 'Employee_115022.Employee_EmailID'

EXEC sp_help Employee_115022

INSERT INTO Employee_115022 (Employee_Code, Employee_Name, Employee_DOB)
VALUES(2001, 'Rosy', '1999-06-06')

SELECT * FROM Employee_115022

GO
--RULE
CREATE RULE DOB_Rule_115022
AS @dob >= '1970-01-01' AND @dob < '2001-01-01'
GO

EXEC sp_bindrule DOB_Rule_115022, 'Employee_115022.Employee_DOB'

INSERT INTO Employee_115022(Employee_Code, Employee_Name, Employee_DOB, Employee_EmailID)
VALUES(2002, 'Ann', '2000-03-02', 'ann@cg.com')